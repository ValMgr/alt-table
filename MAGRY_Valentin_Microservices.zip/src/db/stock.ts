export const stock: Map<string, number> = new Map();
