import { Order } from '@models/order';

export const orders: Map<string, Order> = new Map();
