import { Meal } from '@models/meal';

export const meals: Map<string, Meal> = new Map();
